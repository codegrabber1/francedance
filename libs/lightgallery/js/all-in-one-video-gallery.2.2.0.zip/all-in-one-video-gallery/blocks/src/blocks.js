/**
 * Gutenberg Blocks
 */

import './blocks/categories/index.js';
import './blocks/search/index.js';
import './blocks/video/index.js';
import './blocks/videos/index.js';