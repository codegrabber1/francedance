<?php

/**
 * Categories: List Layout.
 *
 * @link    https://plugins360.com
 * @since   1.0.0
 *
 * @package All_In_One_Video_Gallery
 */
?>

<div class="aiovg aiovg-categories aiovg-categories-list">
	<ul>
		<?php echo $categories_li; ?>
    </ul>
</div>