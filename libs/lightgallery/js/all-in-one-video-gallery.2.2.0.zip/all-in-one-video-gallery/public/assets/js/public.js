(function( $ ) {
	'use strict';
	
	/**
	 * Called when the page has loaded.
	 *
	 * @since 1.0.0
	 */
	$(function() {
		
	});

})( jQuery );
